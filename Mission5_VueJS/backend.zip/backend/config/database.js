module.exports = {
    host                : 'localhost',
    user                : 'greckmin_dbuser',
    password            : 'tKgN+I@fe&fb',
    database            : 'greckmin_webdev_nodejs'
};

// // local
// module.exports = {
//     host                : 'localhost',
//     user                : 'root',
//     password            : '',
//     database            : 'webdev_nodejs'
// };